/*
 * os_darwin.cpp
 *
 * Home page of code is: https://www.smartmontools.org
 *
 * Copyright (C) 2004-8 Geoffrey Keating <geoffk@geoffk.org>
 * Copyright (C) 2014 Alex Samorukov <samm@os2.kiev.ua>
 * Copyright (C) 2026 PeratX <peratx@itxtech.org>
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#include <stdbool.h>
#include <errno.h>
#include <unistd.h>
#include <mach/mach.h>
#include <mach/mach_error.h>
#include <mach/mach_init.h>
#include <sys/utsname.h>
#include <IOKit/IOCFPlugIn.h>
#include <IOKit/IOKitLib.h>
#include <IOKit/IOReturn.h>
#include <IOKit/IOBSD.h>
#include <IOKit/storage/IOBlockStorageDevice.h>
#include <IOKit/storage/IOStorageDeviceCharacteristics.h>
#include <IOKit/storage/IOMedia.h>
#include <IOKit/storage/ata/IOATAStorageDefines.h>
#include <IOKit/storage/ata/ATASMARTLib.h>
#include <CoreFoundation/CoreFoundation.h>

#include "config.h"

#include <algorithm>
#include <array>
#include <memory>

#include <smartmon/atacmds.h>
#include <smartmon/scsicmds.h>
#include <smartmon/nvmecmds.h>
#include <smartmon/utility.h>
#include "os_darwin.h"
#include "os_darwin_usb.h"
#include <smartmon/dev_interface.h>

namespace smartmon {

#define ARGUSED(x) ((void)(x))

// examples for smartctl
static const char  smartctl_examples[] =
         "=================================================== SMARTCTL EXAMPLES =====\n\n"
         "  smartctl -a disk0                            (Prints all SMART information)\n\n"
         "  smartctl -t long /dev/disk0              (Executes extended disk self-test)\n\n"
         "  smartctl --smart=on --saveauto=on /dev/rdisk0 (Enables SMART on first disk)\n\n"
         "  smartctl --attributes --log=selftest --quietmode=errorsonly /dev/disk0\n"
         "                                        (Prints Self-Test & Attribute errors)\n\n"
         "  smartctl -a IOService:/MacRISC2PE/pci@f4000000/AppleMacRiscPCI/ata-6@D/AppleKauaiATA/ATADeviceNub@0/IOATABlockStorageDriver/IOATABlockStorageDevice\n"
         "                                                 (You can use IOService: ...)\n\n"
         "  smartctl -c IODeviceTree:/pci@f4000000/ata-6@D/@0:0\n"
         "                                                       (... Or IODeviceTree:)\n"
         ;


// Information that we keep about each device.

static struct {
  io_object_t ioob;
  IOCFPlugInInterface **plugin;
  IOATASMARTInterface **smartIf; // ATA devices
  IONVMeSMARTInterface **smartIfNVMe;
} devices[20];

/////////////////////////////////////////////////////////////////////////////

namespace os_darwin { // No need to publish anything, name provided for Doxygen

/////////////////////////////////////////////////////////////////////////////
/// Implement shared open/close routines with old functions.

class darwin_smart_device
: virtual public /*implements*/ smart_device
{
public:
  explicit darwin_smart_device(const char * mode)
    : smart_device(never_called),
      m_fd(-1), m_mode(mode) { }

  virtual ~darwin_smart_device();

  virtual bool is_open() const override;

  virtual bool open() override;

  virtual bool close() override;
 
protected:
  /// Return filedesc for derived classes.
  int get_fd() const
    { return m_fd; }
    
private:
  int m_fd; ///< filedesc, -1 if not open.
  const char * m_mode; ///< Mode string for deviceopen().
};


darwin_smart_device::~darwin_smart_device()
{
  if (m_fd >= 0)
    darwin_smart_device::close();
}

bool darwin_smart_device::is_open() const
{
  return (m_fd >= 0);
}

// Determine whether 'dev' is a SMART-capable device.
static bool is_smart_capable (io_object_t dev, const char * type) {
  CFTypeRef smartCapableKey = NULL;
  CFDictionaryRef diskChars;

  // If the device has kIOPropertySMARTCapableKey, then it's capable,
  // no matter what it looks like.
  if (!strcmp("ATA", type))  {
  smartCapableKey = IORegistryEntryCreateCFProperty
    (dev, CFSTR (kIOPropertySMARTCapableKey),
     kCFAllocatorDefault, 0);
  }

  else if (!strcmp("NVME", type)) {
    smartCapableKey = IORegistryEntryCreateCFProperty
      (dev, CFSTR (kIOPropertyNVMeSMARTCapableKey),
       kCFAllocatorDefault, 0);
  }

  if (smartCapableKey)
    {
      CFRelease (smartCapableKey);
      return true;
    }

  // If it's an kIOATABlockStorageDeviceClass then we're successful
  // only if its ATA features indicate it supports SMART.
  // This will be broken for NVMe, however it is not needed
  if (IOObjectConformsTo (dev, kIOATABlockStorageDeviceClass)
    && (diskChars = (CFDictionaryRef)IORegistryEntryCreateCFProperty                                                                                                           
      (dev, CFSTR (kIOPropertyDeviceCharacteristicsKey),
        kCFAllocatorDefault, kNilOptions)) != NULL)
    {
      CFNumberRef diskFeatures = NULL;
      UInt32 ataFeatures = 0;

      if (CFDictionaryGetValueIfPresent (diskChars, CFSTR ("ATA Features"),
        (const void **)&diskFeatures))
      CFNumberGetValue (diskFeatures, kCFNumberLongType,
        &ataFeatures);
      CFRelease (diskChars);
      if (diskFeatures)
        CFRelease (diskFeatures);
      
      return (ataFeatures & kIOATAFeatureSMART) != 0;
    }
  return false;
}

bool darwin_smart_device::open()
{
  // Acceptable device names are:
  // /dev/disk*
  // /dev/rdisk*
  // disk*
  // IOService:*
  // IODeviceTree:*
  size_t devnum;
  const char *devname;
  io_object_t disk;
  const char *pathname = get_dev_name();
  char *type = const_cast<char*>(m_mode);
  
  if (!(strcmp("ATA", type) || strcmp("NVME", type)))
    {
      set_err (EINVAL);
      return false;
    }
  
  // Find a free device number.
  for (devnum = 0; devnum < sizeof (devices) / sizeof (devices[0]); devnum++)
    if (! devices[devnum].ioob)
      break;
  if (devnum == sizeof (devices) / sizeof (devices[0]))
    {
      set_err (EMFILE);
      return false;
    }
  
  devname = NULL;
  if (strncmp (pathname, "/dev/rdisk", 10) == 0)
    devname = pathname + 6;
  else if (strncmp (pathname, "/dev/disk", 9) == 0)
    devname = pathname + 5;
  else if (strncmp (pathname, "disk", 4) == 0)
    // allow user to just say 'disk0'
    devname = pathname;

  // Find the device. This part should be the same for the NVMe and ATA
  if (devname)
    {
      CFMutableDictionaryRef matcher;
      matcher = IOBSDNameMatching (kIOMasterPortDefault, 0, devname);
      disk = IOServiceGetMatchingService (kIOMasterPortDefault, matcher);
    }
  else
    {
      disk = IORegistryEntryFromPath (kIOMasterPortDefault, pathname);
    }
  if (! disk)
    {
      set_err(ENOENT);
      return false;
    }
  // Find a SMART-capable driver which is a parent of this device.
  while (! is_smart_capable (disk, type))
    {
      IOReturn err;
      io_object_t prevdisk = disk;

      // Find this device's parent and try again.
      err = IORegistryEntryGetParentEntry (disk, kIOServicePlane, &disk);
      if (err != kIOReturnSuccess || ! disk)
      {
        set_err(ENODEV);
        IOObjectRelease (prevdisk);
        return false;
      }
    }
  
  devices[devnum].ioob = disk;

  {
    SInt32 dummy;
  
    devices[devnum].plugin = NULL;
    devices[devnum].smartIf = NULL;
    devices[devnum].smartIfNVMe = NULL;

    CFUUIDRef pluginType = NULL;
    CFUUIDRef smartInterfaceId = NULL;
    void ** SMARTptr = NULL;

    if (!strcmp("ATA", type))  {
      pluginType = kIOATASMARTUserClientTypeID;
      smartInterfaceId = kIOATASMARTInterfaceID;
      SMARTptr = (void **)&devices[devnum].smartIf;
    }
    else if (!strcmp("NVME", type)) {
      pluginType = kIONVMeSMARTUserClientTypeID;
      smartInterfaceId = kIONVMeSMARTInterfaceID;
      SMARTptr = (void **)&devices[devnum].smartIfNVMe;
    }

    // Create an interface to the ATA SMART library.
    if (IOCreatePlugInInterfaceForService (disk,
      pluginType,
      kIOCFPlugInInterfaceID,
      &devices[devnum].plugin,
      &dummy) == kIOReturnSuccess)
    (*devices[devnum].plugin)->QueryInterface
    (devices[devnum].plugin,
      CFUUIDGetUUIDBytes ( smartInterfaceId),
      SMARTptr);
    else
      return set_err(ENOSYS, "IOCreatePlugInInterfaceForService failed");
  }


  m_fd = devnum;
  if (m_fd < 0) {
    set_err((errno==ENOENT || errno==ENOTDIR) ? ENODEV : errno);
    return false;
  }
  return true;
}

bool darwin_smart_device::close()
{
  int fd = m_fd; m_fd = -1;
  if (devices[fd].smartIf)
    (*devices[fd].smartIf)->Release (devices[fd].smartIf);
  if (devices[fd].smartIfNVMe)
    (*devices[fd].smartIfNVMe)->Release (devices[fd].smartIfNVMe);
  if (devices[fd].plugin)
    IODestroyPlugInInterface (devices[fd].plugin);
  IOObjectRelease (devices[fd].ioob);
  devices[fd].ioob = MACH_PORT_NULL;
  return true;
}

// makes a list of ATA or SCSI devices for the DEVICESCAN directive of
// smartd.  Returns number N of devices, or -1 if out of
// memory. Allocates N+1 arrays: one of N pointers (devlist); the
// other N arrays each contain null-terminated character strings.  In
// the case N==0, no arrays are allocated because the array of 0
// pointers has zero length, equivalent to calling malloc(0).
static int make_device_names (char*** devlist, const char* name) {
  IOReturn err;
  io_iterator_t i;
  io_object_t device = MACH_PORT_NULL;
  int result;
  int index;

  if (!(strcmp("ATA", name) || strcmp("NVME", name))) {
    return 0;
  }

  err = IOServiceGetMatchingServices 
    (kIOMasterPortDefault, IOServiceMatching (kIOBlockStorageDeviceClass), &i);
  if (err != kIOReturnSuccess)
    return -1;

  // Count the devices.
  result = 0;
  while ((device = IOIteratorNext (i)) != MACH_PORT_NULL) {
    if (is_smart_capable (device, name))
      result++;
    IOObjectRelease (device);
  }

  // Create an array of service names.
  IOIteratorReset (i);
  if (! result)
    goto error;
  *devlist = (char**)calloc (result, sizeof (char *)); 
  index = 0;
  while ((device = IOIteratorNext (i)) != MACH_PORT_NULL) {
    if (is_smart_capable (device, name))
    {
      io_string_t devName;
      IORegistryEntryGetPath(device, kIOServicePlane, devName);
      (*devlist)[index] = strdup (devName);
      if (! (*devlist)[index])
        goto error;
      index++;
    }
    IOObjectRelease (device);
  }

  IOObjectRelease (i);
  return result;

 error:
  if (device != MACH_PORT_NULL)
    IOObjectRelease (device);
  IOObjectRelease (i);
  if (*devlist)
  {
    for (index = 0; index < result; index++)
      if ((*devlist)[index])
        free ((*devlist)[index]);
    free (*devlist);
  }
  if(!result) // no devs found
    return 0;

  return -1;
}

/////////////////////////////////////////////////////////////////////////////
/// Implement standard ATA support

class darwin_ata_device
: public /*implements*/ ata_device,
  public /*extends*/ darwin_smart_device
{
public:
  darwin_ata_device(smart_interface * intf, const char * dev_name, const char * req_type);
  virtual bool ata_pass_through(const ata_cmd_in & in, ata_cmd_out & out) override;

protected:
  // virtual int ata_command_interface(smart_command_set command, int select, char * data);
};

/////////////////////////////////////////////////////////////////////////////
/// Raw USB SCSI transport using IOUSBHost DeviceCapture.

class darwin_usb_scsi_device
: public /*implements*/ scsi_device
{
public:
  darwin_usb_scsi_device(smart_interface * intf, const char * dev_name,
    const char * req_type, uint64_t registry_id = 0,
    darwin_usb_protocol protocol = darwin_usb_protocol::none);
  virtual ~darwin_usb_scsi_device();

  virtual bool is_open() const override;
  virtual bool open() override;
  virtual bool close() override;
  virtual bool scsi_pass_through(scsi_cmnd_io * iop) override;

private:
  darwin_usb_scsi_device(const darwin_usb_scsi_device &) = delete;
  void operator=(const darwin_usb_scsi_device &) = delete;

  darwin_usb_handle * m_handle = nullptr;
  uint64_t m_registry_id;
  darwin_usb_protocol m_protocol;
};

darwin_usb_scsi_device::darwin_usb_scsi_device(smart_interface * intf,
  const char * dev_name, const char * req_type, uint64_t registry_id,
  darwin_usb_protocol protocol)
: smart_device(intf, dev_name, "scsi", req_type), m_registry_id(registry_id),
  m_protocol(protocol)
{
}

darwin_usb_scsi_device::~darwin_usb_scsi_device()
{
  if (m_handle && !close())
    lib_printf("%s: raw USB cleanup failed: %s\n", get_dev_name(), get_errmsg());
}

bool darwin_usb_scsi_device::is_open() const
{
  return !!m_handle;
}

bool darwin_usb_scsi_device::open()
{
  if (m_handle)
    return true;

  int err = 0;
  std::string errmsg;
  m_handle = darwin_usb_open(get_dev_name(), m_registry_id, err, errmsg, m_protocol);
  if (!m_handle)
    return set_err(err ? err : EIO, "%s", errmsg.c_str());
  set_info().info_name = strprintf("%s [USB %s]", get_dev_name(),
    darwin_usb_transport_name(m_handle));
  return true;
}

bool darwin_usb_scsi_device::close()
{
  if (!m_handle)
    return true;
  int err = 0;
  std::string errmsg;
  bool ok = darwin_usb_close(m_handle, err, errmsg);
  m_handle = nullptr;
  if (!ok)
    return set_err(err ? err : EIO, "%s", errmsg.c_str());
  return true;
}

bool darwin_usb_scsi_device::scsi_pass_through(scsi_cmnd_io * iop)
{
  if (!m_handle)
    return set_err(EBADF, "raw USB device is not open");

  int err = 0;
  std::string errmsg;
  if (!darwin_usb_scsi_pass_through(m_handle, iop, err, errmsg))
    return set_err(err ? err : EIO, "%s", errmsg.c_str());
  return true;
}

darwin_ata_device::darwin_ata_device(smart_interface * intf, const char * dev_name, const char * req_type)
: smart_device(intf, dev_name, "ata", req_type),
  darwin_smart_device("ATA")
{
}

bool darwin_ata_device::ata_pass_through(const ata_cmd_in & in, ata_cmd_out & out)
{
  if (!ata_cmd_is_ok(in,
    true, // data_out_support
    true, // multi_sector_support
    false) // not supported by API
    )
  return false;
  
  int select = 0;
  char * data = (char *)in.buffer;
  int fd = get_fd();
  IOATASMARTInterface **ifp = devices[fd].smartIf;
  IOATASMARTInterface *smartIf;
  io_object_t disk = devices[fd].ioob;
  IOReturn err;
  int timeoutCount = 5;
  int rc = 0;
  
  if (! ifp)
    return false;
  smartIf = *ifp;
  clear_err(); errno = 0;
  do {
  switch (in.in_regs.command) {
    case ATA_IDENTIFY_DEVICE:
      {
        UInt32 dummy;
        err = smartIf->GetATAIdentifyData (ifp, data, 512, &dummy);
        if (err != kIOReturnSuccess && err != kIOReturnTimeout
          && err != kIOReturnNotResponding)
        printf ("identify failed: %#x\n", (unsigned) rc);
        if (err == kIOReturnSuccess && byteorder_is_big_endian)
          /* The system has already byte-swapped, undo it.  */
          byteswap_array_16_inplace((uint8_t *)in.buffer, in.size);
      }
      break;
    case ATA_IDENTIFY_PACKET_DEVICE:
    case ATA_CHECK_POWER_MODE:
      errno = ENOTSUP;
      err = -1;
      break;
    case ATA_SET_FEATURES:
      switch(in.in_regs.features) {
        case ATA_ENABLE_APM:
        if (in.in_regs.sector_count) {
          int l = (int) in.in_regs.sector_count;
          CFNumberRef cfLevel = CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &l);
          kern_return_t r = IORegistryEntrySetCFProperty(disk, CFSTR("APM Level"), cfLevel);
          CFRelease(cfLevel);
          if (r) {
            switch(r) {
              case kIOReturnNotPrivileged:
                return set_err(ENOSYS, "Use superuser to manage APM");
                break;
              case kIOReturnUnsupported:
                return set_err(ENOSYS, "APM not supported");
                break;
              default:
                return set_err(ENOSYS, "APM error: %u", r);
            }
          }
          break;
        }
        default:
          return set_err(ENOSYS, "Unsupported ATA feature");
        }
      break;
    case ATA_SMART_CMD:
      switch (in.in_regs.features) {
      case ATA_SMART_READ_VALUES:
        err = smartIf->SMARTReadData (ifp, (ATASMARTData *)data);
        break;
      case ATA_SMART_READ_THRESHOLDS:
        err = smartIf->SMARTReadDataThresholds (ifp, 
          (ATASMARTDataThresholds *)data);
        break;
      case ATA_SMART_READ_LOG_SECTOR:
        err = smartIf->SMARTReadLogAtAddress (ifp, in.in_regs.lba_low, data, 512 * in.in_regs.sector_count);
        break;
      case ATA_SMART_WRITE_LOG_SECTOR:
        err = smartIf->SMARTWriteLogAtAddress (ifp, in.in_regs.lba_low, data, 512 * in.in_regs.sector_count);
        break;
      case ATA_SMART_ENABLE:
      case ATA_SMART_DISABLE:
        err = smartIf->SMARTEnableDisableOperations (ifp, in.in_regs.features == ATA_SMART_ENABLE);
        break;
      case ATA_SMART_STATUS:
        if (in.out_needed.lba_high) // statuscheck
        {
          Boolean is_failing;
          err = smartIf->SMARTReturnStatus (ifp, &is_failing);
          if (err == kIOReturnSuccess && is_failing) {
            err = -1; // thresholds exceeded condition
            out.out_regs.lba_high = 0x2c; out.out_regs.lba_mid = 0xf4;
          }
          else {
            out.out_regs.lba_high = 0xc2; out.out_regs.lba_mid = 0x4f;
          }
          break;
        }
        else err = 0;
        break;
      case ATA_SMART_AUTOSAVE:
        err = smartIf->SMARTEnableDisableAutosave (ifp, 
          (in.in_regs.sector_count == 241 ? true : false));
        break;
      case ATA_SMART_IMMEDIATE_OFFLINE:
        select = in.in_regs.lba_low;
        if (select != SHORT_SELF_TEST && select != EXTEND_SELF_TEST)
        {
          errno = EINVAL;
          return set_err(ENOSYS, "Unsupported SMART self-test mode");
        }
        err = smartIf->SMARTExecuteOffLineImmediate (ifp, 
          select == EXTEND_SELF_TEST);
        break;
      case ATA_SMART_AUTO_OFFLINE:
        return set_err(ENOSYS, "SMART command not supported");
      default:
        return set_err(ENOSYS, "Unknown SMART command");
      }
      break;
    default:
      return set_err(ENOSYS, "Non-SMART commands not implemented");
    }
  } while ((err == kIOReturnTimeout || err == kIOReturnNotResponding)
  && timeoutCount-- > 0);
  if (err == kIOReturnExclusiveAccess)
    errno = EBUSY;
  rc = err == kIOReturnSuccess ? 0 : -1;
  if (rc < 0) {
    if (!get_errno())
      set_err(errno);
    return false;
  }
  return true;
}

/////////////////////////////////////////////////////////////////////////////
/// Implement platform interface

class darwin_smart_interface
: public /*implements*/ smart_interface
{
public:
  virtual std::string get_os_version_str() override;

  virtual std::string get_app_examples(const char * appname) override;

protected:
  virtual bool scan_smart_devices(smart_device_list & devlist, const char * type,
    const char * pattern = 0) override;

  virtual ata_device * get_ata_device(const char * name, const char * type) override;
  
  virtual scsi_device * get_scsi_device(const char * name, const char * type) override;

  virtual nvme_device * get_nvme_device(const char * name, const char * type,
    unsigned nsid) override;

  virtual smart_device * autodetect_smart_device(const char * name) override;

  virtual smart_device * get_custom_smart_device(const char * name,
    const char * type) override;
  virtual std::string get_valid_custom_dev_types_str() override;

private:
  smart_device * get_usb_smart_device(const char * name,
    const darwin_usb_device_info & info, const char * type);
  bool scan_usb_smart_devices(smart_device_list & devlist);
};

static bool is_supported_darwin_usb_type(const char * type)
{
  if (!type)
    return false;
  if (str_starts_with(type, "sat") && (!type[3] || type[3] == ','))
    return true;

  static const std::array<std::string, 3> snt_types = {{
    "sntasmedia", "sntjmicron", "sntrealtek"
  }};
  return std::any_of(snt_types.begin(), snt_types.end(),
    [type](const std::string & snt_type) {
      const size_t length = snt_type.size();
      return !strncmp(type, snt_type.c_str(), length)
        && (!type[length] || type[length] == ',' || type[length] == '/');
    });
}

/////////////////////////////////////////////////////////////////////////////
/// NVMe support

class darwin_nvme_device
: public /*implements*/ nvme_device,
  public /*extends*/ darwin_smart_device
{
public:
  darwin_nvme_device(smart_interface * intf, const char * dev_name,
    const char * req_type, unsigned nsid);

  virtual bool nvme_pass_through(const nvme_cmd_in & in, nvme_cmd_out & out) override;
};

darwin_nvme_device::darwin_nvme_device(smart_interface * intf, const char * dev_name,
  const char * req_type, unsigned nsid)
: smart_device(intf, dev_name, "nvme", req_type),
  nvme_device(nsid),
  darwin_smart_device("NVME")
{
}

bool darwin_nvme_device::nvme_pass_through(const nvme_cmd_in & in, nvme_cmd_out & out)
{
  ARGUSED(out);
  int fd = get_fd();
  IONVMeSMARTInterface **ifp = devices[fd].smartIfNVMe;
  IONVMeSMARTInterface *smartIfNVMe ;
  IOReturn err = 0;
  unsigned int page = in.cdw10 & 0xff;

  if (! ifp)
    return false;
  smartIfNVMe = *ifp;
  // currently only GetIdentifyData and GetLogPage are supported
  switch (in.opcode) {
    case nvme_admin_identify:
      err = smartIfNVMe->GetIdentifyData(ifp, (struct nvme_id_ctrl *) in.buffer, in.nsid);
      if (err)
        return set_err(ENOSYS, "GetIdentifyData failed: system=0x%x, sub=0x%x, code=%d",
          err_get_system(err), err_get_sub(err), err_get_code(err));
      break;
    case nvme_admin_get_log_page:
      err = smartIfNVMe->GetLogPage(ifp, in.buffer, page, in.size / 4 - 1);
      if (err)
        return set_err(ENOSYS, "GetLogPage failed: system=0x%x, sub=0x%x, code=%d",
          err_get_system(err), err_get_sub(err), err_get_code(err));
      break;
    default:
      return set_err(ENOSYS, "NVMe admin command 0x%02x is not supported", in.opcode);
  }
  return true;
}
//////////////////////////////////////////////////////////////////////

std::string darwin_smart_interface::get_os_version_str()
{
  // now we are just getting darwin runtime version, to get OSX version more things needs to be done, see
  // http://stackoverflow.com/questions/11072804/how-do-i-determine-the-os-version-at-runtime-in-os-x-or-ios-without-using-gesta
  struct utsname osname;
  uname(&osname);
  return strprintf("%s %s %s", osname.sysname, osname.release, osname.machine);
}

std::string darwin_smart_interface::get_app_examples(const char * appname)
{
  if (!strcmp(appname, "smartctl"))
    return smartctl_examples;
  return ""; // ... so don't print again.
}

ata_device * darwin_smart_interface::get_ata_device(const char * name, const char * type)
{
  return new darwin_ata_device(this, name, type);
}

scsi_device * darwin_smart_interface::get_scsi_device(const char * name, const char * type)
{
  if (!darwin_usb_is_device_name(name))
    return nullptr; // The system SCSI stack still has no general pass-through API.
  std::unique_ptr<scsi_device> dev(
    new darwin_usb_scsi_device(this, name, type));
  return dev.release();
}

smart_device * darwin_smart_interface::get_custom_smart_device(const char * name,
  const char * type)
{
  // Keep bridge protocol/namespace parsing in the existing SAT/SNT factories.
  // The suffix selects the USB wire protocol independently of the bridge.
  const char * suffix = strstr(type, "+usb,");
  if (!suffix)
    return nullptr;
  if (!darwin_usb_is_device_name(name))
    return set_err_np(EINVAL, "USB transport selection requires a Darwin USB device name");
  const std::string bridge_type(type, suffix - type);
  if (!is_supported_darwin_usb_type(bridge_type.c_str()) && bridge_type != "scsi")
    return set_err_np(EINVAL, "USB transport selection requires a SAT, SNT or SCSI device type");
  darwin_usb_protocol protocol;
  if (!strcmp(suffix, "+usb,bot"))
    protocol = darwin_usb_protocol::bot;
  else if (!strcmp(suffix, "+usb,uasp"))
    protocol = darwin_usb_protocol::uasp;
  else
    return set_err_np(EINVAL, "USB transport must be 'bot' or 'uasp'");
  scsi_device * scsidev = new darwin_usb_scsi_device(this, name, type, 0, protocol);
  if (bridge_type == "scsi")
    return scsidev;
  return get_scsi_passthrough_device(bridge_type.c_str(), scsidev);
}

std::string darwin_smart_interface::get_valid_custom_dev_types_str()
{
  return "<sat|sntasmedia|sntjmicron[,NSID]|sntrealtek|scsi>+usb,<bot|uasp>";
}

nvme_device * darwin_smart_interface::get_nvme_device(const char * name, const char * type,
  unsigned nsid)
{
  return new darwin_nvme_device(this, name, type, nsid);
}

smart_device * darwin_smart_interface::get_usb_smart_device(const char * name,
  const darwin_usb_device_info & info, const char * type)
{
  const char * usbtype = type;
  if (!usbtype || !*usbtype) {
    usbtype = get_usb_dev_type_by_id(info.vendor_id, info.product_id,
      info.device_version);
    if (!is_supported_darwin_usb_type(usbtype)) {
      // A standard SAT INQUIRY is safe for an unknown or unsupported bridge.
      // Vendor-specific SNT commands are selected only from the drive database.
      clear_err();
      usbtype = "sat,auto";
    }
  }

  std::unique_ptr<scsi_device> scsidev(
    new darwin_usb_scsi_device(this, name, "", info.registry_id));
  if (!strcmp(usbtype, "scsi"))
    return scsidev.release();
  return get_scsi_passthrough_device(usbtype, scsidev.release());
}

smart_device * darwin_smart_interface::autodetect_smart_device(const char * name)
{
  const bool explicit_raw = !strncmp(name, "usbraw:", 7);
  if (!explicit_raw) {
    // Prefer native ATA SMART drivers, including third-party SAT drivers.
    // For NVMe, a native capability key is insufficient on some USB bridges:
    // the driver may provide Identify but reject SMART GetLogPage.
    const char * bsd_name = nullptr;
    if (!strncmp(name, "/dev/rdisk", 10))
      bsd_name = name + 6;
    else if (!strncmp(name, "/dev/disk", 9))
      bsd_name = name + 5;
    else if (!strncmp(name, "disk", 4))
      bsd_name = name;
    io_service_t service = bsd_name
      ? IOServiceGetMatchingService(MACH_PORT_NULL,
          IOBSDNameMatching(MACH_PORT_NULL, 0, bsd_name))
      : IORegistryEntryFromPath(MACH_PORT_NULL, name);
    if (!service)
      return nullptr;
    while (service) {
      const bool ata = is_smart_capable(service, "ATA");
      const bool nvme = !ata && is_smart_capable(service, "NVME");
      io_service_t parent = MACH_PORT_NULL;
      if (!ata && !nvme)
        IORegistryEntryGetParentEntry(service, kIOServicePlane, &parent);
      IOObjectRelease(service);
      if (ata)
        return new darwin_ata_device(this, name, "");
      if (nvme) {
        darwin_usb_device_info info;
        int error = 0;
        std::string message;
        if (darwin_usb_get_device_info(name, info, error, message)) {
          const char * type = get_usb_dev_type_by_id(info.vendor_id,
            info.product_id, info.device_version);
          if (type && str_starts_with(type, "snt")
              && is_supported_darwin_usb_type(type))
            return get_usb_smart_device(name, info, type);
          clear_err();
        }
        return new darwin_nvme_device(this, name, "", 0);
      }
      service = parent;
    }
  }

  darwin_usb_device_info usb_info;
  int usb_error = 0;
  std::string usb_error_message;
  if (darwin_usb_get_device_info(name, usb_info, usb_error, usb_error_message))
    return get_usb_smart_device(name, usb_info, nullptr);
  if (explicit_raw)
    return set_err_np(usb_error ? usb_error : ENODEV, "%s",
      usb_error_message.c_str());

  // Preserve the legacy ATA fallback for devices without a native SMART key.
  return new darwin_ata_device(this, name, "");
}


static void free_devnames(char * * devnames, int numdevs)
{
  for (int i = 0; i < numdevs; i++)
    free(devnames[i]);
  free(devnames);
}

bool darwin_smart_interface::scan_usb_smart_devices(smart_device_list & devlist)
{
  std::vector<darwin_usb_device_info> usb_devices;
  int usb_error = 0;
  std::string usb_error_message;
  if (!darwin_usb_scan_devices(usb_devices, usb_error, usb_error_message))
    return set_err(usb_error ? usb_error : EIO, "%s",
      usb_error_message.c_str());

  for (std::vector<darwin_usb_device_info>::const_iterator it =
      usb_devices.begin(); it != usb_devices.end(); ++it) {
    smart_device * dev = get_usb_smart_device(it->device_name.c_str(), *it,
      nullptr);
    if (!dev)
      return false;
    devlist.push_back(dev);
  }
  return true;
}

bool darwin_smart_interface::scan_smart_devices(smart_device_list & devlist,
  const char * type, const char * pattern /*= 0*/)
{
  if (pattern) {
    set_err(EINVAL, "DEVICESCAN with pattern not implemented yet");
    return false;
  }

  // Raw USB access captures the complete device and temporarily unmounts its
  // volumes.  Never add these devices to default scans, even after the
  // transport has been tested: smartd repeatedly opens scanned devices.
  if (type && !strcmp(type, "usb"))
    return scan_usb_smart_devices(devlist);

  // Make namelists
  char * * atanames = 0; int numata = 0;
  if (!type || !strcmp(type, "ata")) {
    numata = make_device_names(&atanames, "ATA");
    if (numata < 0) {
      set_err(ENOMEM);
      return false;
    }
  }
  char * * nvmenames = 0; int numnvme = 0;
  if (!type || !strcmp(type, "nvme")) {
    numnvme = make_device_names(&nvmenames, "NVME");
    if (numnvme < 0) {
      set_err(ENOMEM);
      return false;
    }
  }

  // Add to devlist
  int i;
  if (!type)
    type="";
  for (i = 0; i < numata; i++) {
    ata_device * atadev = get_ata_device(atanames[i], type);
    if (atadev)
      devlist.push_back(atadev);
  }
  free_devnames(atanames, numata);

  for (i = 0; i < numnvme; i++) {
    nvme_device * nvmedev = get_nvme_device(nvmenames[i], type, 0); // default nsid
    if (nvmedev)
      devlist.push_back(nvmedev);
  }  
  free_devnames(nvmenames, numnvme);

  return true;
}

} // namespace os_darwin


/////////////////////////////////////////////////////////////////////////////
/// Initialize platform interface and register with smi()

void smart_interface::init()
{
  static os_darwin::darwin_smart_interface the_interface;
  smart_interface::set(&the_interface);
}

} // namespace smartmon
