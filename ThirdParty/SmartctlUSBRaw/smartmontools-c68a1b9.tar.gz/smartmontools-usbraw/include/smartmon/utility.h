/*
 * utility.h
 *
 * Home page of code is: https://www.smartmontools.org
 *
 * Copyright (C) 2002-11 Bruce Allen
 * Copyright (C) 2008-26 Christian Franke
 * Copyright (C) 2000 Michael Cornwell <cornwell@acm.org>
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef SMARTMON_UTILITY_H
#define SMARTMON_UTILITY_H

#include <smartmon/smartmon_defs.h>

#include <float.h> // *DBL_MANT_DIG
#include <time.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory>
#include <new>
#include <string>

namespace smartmon {

/// Class to register an application specific lib_vprintf() function.
class lib_global_hook
{
public:
  lib_global_hook() = default;
  virtual ~lib_global_hook() = default;
  lib_global_hook(const lib_global_hook &) = delete;
  void operator=(const lib_global_hook &) = delete;

  /// Get the current hook.
  static lib_global_hook & get();

  /// Set the hook.
  static void set(lib_global_hook & hook);

  /// Reset to default hook.
  static void reset();

  /// Called by global lib_vprintf().
  /// The default implementation calls vprintf().
  virtual void lib_vprintf(const char * fmt, va_list ap);
};

/// Like vprintf() but calls lib_global_hook::get().lib_vprintf()
void lib_vprintf(const char * fmt, va_list ap);

/// Like printf() but calls lib_vprintf().
void lib_printf(const char * fmt, ...)
  SMARTMON_FORMAT_PRINTF(1, 2);

// Global to set failure tolerance
extern unsigned char failuretest_permissive;

// Make version information string
// lines: 1: version only, 2: version+copyright, >=3: full information
std::string format_version_info(const char * prog_name, int lines = 2);

// return (v)sprintf() formatted std::string
std::string strprintf(const char * fmt, ...)
  SMARTMON_FORMAT_PRINTF(1, 2);
std::string vstrprintf(const char * fmt, va_list ap);

// Return true if STR starts with PREFIX
inline bool str_starts_with(const char * str, const char * prefix)
  { return !strncmp(str, prefix, strlen(prefix)); }

inline bool str_starts_with(const std::string & str, const char * prefix)
  { return !strncmp(str.c_str(), prefix, strlen(prefix)); }

// Convert time to broken-down local time, throw on error.
struct tm * time_to_tm_local(struct tm * tp, time_t t);

// Utility function prints date and time and timezone into a character
// buffer of length 64.  All the fuss is needed to get the
// right timezone info (sigh).
#define DATEANDEPOCHLEN 64
void dateandtimezoneepoch(char (& buffer)[DATEANDEPOCHLEN], time_t tval);

// replacement for perror() with redirected output.
void syserror(const char * message);

// Function for processing -t selective... option in smartctl
int split_selective_arg(char *s, uint64_t *start, uint64_t *stop, int *mode);

// Runtime check of ./configure result, throws on error.
void check_config();

// This value follows the peripheral device type value as defined in
// SCSI Primary Commands, ANSI INCITS 301:1997.  It is also used in
// the ATA standard for packet devices to define the device type.
const char *packetdevicetype(int type);

// returns true if any of the n bytes are nonzero, else zero.
bool nonempty(const void * data, int size);

// needed to fix glibc bug
void FixGlibcTimeZoneBug();

// Cast any char pointer to default char pointer.
static inline char * to_char_ptr(char * p) { return p; }
static inline char * to_char_ptr(signed char * p) { return reinterpret_cast<char *>(p); }
static inline char * to_char_ptr(unsigned char * p) { return reinterpret_cast<char *>(p); }
static inline const char * to_char_ptr(const char * p) { return p; }
static inline const char * to_char_ptr(const signed char * p) { return reinterpret_cast<const char *>(p); }
static inline const char * to_char_ptr(const unsigned char * p) { return reinterpret_cast<const char *>(p); }

// Copy not null terminated char array to null terminated string.
// Replace non-ascii characters.  Remove leading and trailing blanks.
const char * format_char_array(char * str, int strsize, const char * chr, int chrsize);

// Variant for '[un]signed char' aka '[u]int8_t'.
template<typename STRTYPE, typename CHRTYPE>
static inline const STRTYPE * format_char_array(STRTYPE * str, int strsize, const CHRTYPE * chr, int chrsize)
{
  return reinterpret_cast<const STRTYPE *>(
    format_char_array(to_char_ptr(str), strsize, to_char_ptr(chr), chrsize)
  );
}

// Variants for fixed size buffers.
template<typename STRTYPE, size_t STRSIZE, typename CHRTYPE, size_t CHRSIZE>
static inline const STRTYPE * format_char_array(STRTYPE (& str)[STRSIZE], const CHRTYPE (& chr)[CHRSIZE])
  { return format_char_array(str, (int)STRSIZE, chr, (int)CHRSIZE); }

template<typename STRTYPE, size_t STRSIZE, typename CHRTYPE>
static inline const STRTYPE * format_char_array(STRTYPE (& str)[STRSIZE], const CHRTYPE * chr, int chrsize)
  { return format_char_array(str, (int)STRSIZE, chr, chrsize); }

template<typename STRTYPE, typename CHRTYPE, size_t CHRSIZE>
static inline const STRTYPE * format_char_array(STRTYPE * str, int strsize, const CHRTYPE (& chr)[CHRSIZE])
  { return format_char_array(str, strsize, chr, (int)CHRSIZE); }

// Format integer with thousands separator
const char * format_with_thousands_sep(char * str, int strsize, uint64_t val,
                                       const char * thousands_sep = 0);

// Format capacity with SI prefixes
const char * format_capacity(char * str, int strsize, uint64_t val,
                             const char * decimal_point = 0);

// Deleter for 'unique_malloced_ptr' below
template<typename T>
struct malloced_ptr_deleter {
  void operator()(T * p)
    {
      SMARTMON_STATIC_ASSERT(std::is_trivial<T>::value);
      free(p);
    }
};

template<typename T>
struct malloced_ptr_deleter<T[]> {
  void operator()(T * p)
    {
      SMARTMON_STATIC_ASSERT(std::is_trivial<T>::value);
      free(p);
    }
};

/// Variant of 'unique_ptr' for pointers which require 'free()' instead of 'delete'
template<typename T>
using unique_malloced_ptr = std::unique_ptr<T, malloced_ptr_deleter<T>>;

/// Resize the array at PTR to SIZE elements of type T, return false on error.
template<typename T>
bool realloc_malloced_ptr_nothrow(unique_malloced_ptr<T[]> & ptr, size_t size)
{
  if (size > SIZE_MAX / sizeof(T))
    return false;
  if (size == 0) {
    // Call 'free()' because POSIX also allows that 'realloc(p, 0)' fails
    ptr.reset();
    return true;
  }
  T * p1 = ptr.release();
  T * p2 = reinterpret_cast<T *>(realloc(p1, size * sizeof(T)));
  if (!p2) {
    ptr.reset(p1);
    return false;
  }
  ptr.reset(p2);
  return true;
}

/// Resize the array at PTR to SIZE elements of type T, throw on error.
template<typename T>
void realloc_malloced_ptr(unique_malloced_ptr<T[]> & ptr, size_t size)
{
  if (!realloc_malloced_ptr_nothrow(ptr, size))
    throw std::bad_alloc();
}

// Wrapper class for a raw data buffer
class raw_buffer
{
public:
  explicit raw_buffer(unsigned sz, unsigned char val = 0)
    : m_data(new unsigned char[sz]),
      m_size(sz)
    { memset(m_data, val, m_size); }

  ~raw_buffer()
    { delete [] m_data; }

  unsigned size() const
    { return m_size; }

  unsigned char * data()
    { return m_data; }
  const unsigned char * data() const
    { return m_data; }

private:
  unsigned char * m_data;
  unsigned m_size;

  raw_buffer(const raw_buffer &);
  void operator=(const raw_buffer &);
};

/// Wrapper class for FILE *.
class stdio_file
{
public:
  explicit stdio_file(FILE * f = 0, bool owner = false)
    : m_file(f), m_owner(owner) { }

  stdio_file(const char * name, const char * mode)
    : m_file(fopen(name, mode)), m_owner(true) { }

  ~stdio_file()
    {
      if (m_file && m_owner)
        fclose(m_file);
    }

  bool open(const char * name, const char * mode)
    {
      if (m_file && m_owner)
        fclose(m_file);
      m_file = fopen(name, mode);
      m_owner = true;
      return !!m_file;
    }

  void open(FILE * f, bool owner = false)
    {
      if (m_file && m_owner)
        fclose(m_file);
      m_file = f;
      m_owner = owner;
    }

  bool close()
    {
      if (!m_file)
        return true;
      bool ok = !ferror(m_file);
      if (fclose(m_file))
        ok = false;
      m_file = 0;
      return ok;
    }

  operator FILE * ()
    { return m_file; }

  bool operator!() const
    { return !m_file; }

private:
  FILE * m_file;
  bool m_owner;

  stdio_file(const stdio_file &);
  void operator=(const stdio_file &);
};

/// Wrapper class for POSIX regex(3) or std::regex
/// Supports copy & assignment and is compatible with STL containers.
class regular_expression
{
public:
  // Construction & assignment
  regular_expression();

  ~regular_expression();

  regular_expression(const regular_expression & x);

  regular_expression & operator=(const regular_expression & x);

  /// Construct with pattern, throw on error.
  explicit regular_expression(const char * pattern);

  /// Set and compile new pattern, return false on error.
  bool compile(const char * pattern);

  // Get pattern from last compile().
  const char * get_pattern() const
    { return m_pattern.c_str(); }

  /// Get error message from last compile().
  const char * get_errmsg() const
    { return m_errmsg.c_str(); }

  /// Return true if pattern is not set or bad.
  bool empty() const
    { return (m_pattern.empty() || !m_errmsg.empty()); }

  /// Return true if full string matches pattern
  bool full_match(const char * str) const;

  /// regex(3)-like match result
  struct match_range { int rm_so, rm_eo; };

  /// Return true if substring matches pattern, fill match_range array.
  bool execute(const char * str, unsigned nmatch, match_range * pmatch) const;

  // Variant for fixed sized array.
  template<size_t SIZE>
  bool execute(const char * str, match_range (& match)[SIZE]) const
    { return execute(str, (unsigned)SIZE, match); }

private:
  std::string m_pattern;
  std::string m_errmsg;
  void * m_regex_p; // Points to hidden 'regex_t' or 'std::regex'

  void copy_regex(const regular_expression & x);
  void free_regex();
  bool compile();
};

// 128-bit unsigned integer to string conversion.
// Provides full integer precision if compiler supports '__int128'.
// Otherwise precision depends on supported floating point data types.

#if defined(SMARTMON_HAVE_LONG_DOUBLE_WIDER) && \
    (!defined(__MINGW32__) || __USE_MINGW_ANSI_STDIO)
    // MinGW 'long double' type does not work with MSVCRT/UCRT *printf()
#define SMARTMON_HAVE_LONG_DOUBLE_WIDER_PRINTF 1
#else
#undef SMARTMON_HAVE_LONG_DOUBLE_WIDER_PRINTF
#endif

// Return #bits precision provided by uint128_hilo_to_str().
inline int uint128_to_str_precision_bits()
{
#if defined(SMARTMON_HAVE___INT128)
  return 128;
#elif defined(SMARTMON_HAVE_LONG_DOUBLE_WIDER_PRINTF)
  return LDBL_MANT_DIG;
#else
  return DBL_MANT_DIG;
#endif
}

// Convert 128-bit unsigned integer provided as two 64-bit halves to a string.
const char * uint128_hilo_to_str(char * str, int strsize, uint64_t value_hi, uint64_t value_lo);

// Version for fixed size buffers.
template <size_t SIZE>
inline const char * uint128_hilo_to_str(char (& str)[SIZE], uint64_t value_hi, uint64_t value_lo)
  { return uint128_hilo_to_str(str, (int)SIZE, value_hi, value_lo); }

/// Get microseconds since some unspecified starting point.
/// Used only for command duration measurements in debug outputs.
/// Returns -1 if unsupported.
long long get_timer_usec();

#ifdef _WIN32
// Get exe directory
//(implemented in os_win32.cpp)
std::string get_exe_dir();
#endif

} // namespace smartmon

#endif // SMARTMON_UTILITY_H
